r"""
"""
__version__ = '0.2.1'
__all__ = ['load',]

__author__ = 'Bin Xue <bin.xue@alibaba-inc.com>'

from .aec import MinDAEC

def load():
    return MinDAEC()

