import ctypes
import os
import platform

import numpy as np
from numpy.ctypeslib import ndpointer


class MinDAEC:
    NAME = 'libpyio'

    def __init__(self):
        p = platform.platform()
        suffix = '.so'
        if p.startswith('Darwin'):
            suffix = '.dylib'
        lib_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), MinDAEC.NAME + suffix)
        clib = ctypes.cdll.LoadLibrary(lib_path)
        self.fe = clib.fe_process_inst
        self.fe.argtypes = [
            ndpointer(ctypes.c_float, flags='C_CONTIGUOUS'),
            ndpointer(ctypes.c_float, flags='C_CONTIGUOUS'),
            ctypes.c_int,
            ndpointer(ctypes.c_float, flags='C_CONTIGUOUS'),
            ndpointer(ctypes.c_float, flags='C_CONTIGUOUS'),
            ndpointer(ctypes.c_float, flags='C_CONTIGUOUS')
        ]

    def do_linear_aec(self, mic, ref, int16range=True):
        mic = np.float32(mic)
        ref = np.float32(ref)
        if len(mic) > len(ref):
            mic = mic[:len(ref)]
        out_mic = np.zeros_like(mic)
        out_linear = np.zeros_like(mic)
        out_echo = np.zeros_like(mic)
        out_ref = np.zeros_like(mic)
        if int16range:
            mic /= 32768
            ref /= 32768
        self.fe(mic, ref, len(mic), out_mic, out_linear, out_echo)
        # out_ref not in use here
        if int16range:
            out_mic *= 32768
            out_linear *= 32768
            out_echo *= 32768
        return out_mic, out_ref, out_linear, out_echo


if __name__ == '__main__':
    aec = MinDAEC()

