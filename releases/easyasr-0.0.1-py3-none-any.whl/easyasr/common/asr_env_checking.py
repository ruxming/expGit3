import os
import shutil
import ssl

import nltk


try:
    nltk.data.find('taggers/averaged_perceptron_tagger')
except LookupError:
    data_dir = nltk.data.find('.')
    target_dir = os.path.join(data_dir, 'taggers')
    if not os.path.exists(target_dir):
        os.mkdir(target_dir)
    src_file = os.path.join(os.path.dirname(__file__),
                            '..',
                            'nltk_packages',
                            'averaged_perceptron_tagger.zip')
    shutil.copyfile(src_file,
                    os.path.join(target_dir, 'averaged_perceptron_tagger.zip'))
    shutil._unpack_zipfile(os.path.join(target_dir, 'averaged_perceptron_tagger.zip'),
                           target_dir)


try:
    nltk.data.find('corpora/cmudict')
except LookupError:
    data_dir = nltk.data.find('.')
    target_dir = os.path.join(data_dir, 'corpora')
    if not os.path.exists(target_dir):
        os.mkdir(target_dir)
    src_file = os.path.join(os.path.dirname(__file__),
                            '..',
                            'nltk_packages',
                            'cmudict.zip')
    shutil.copyfile(src_file,
                    os.path.join(target_dir, 'cmudict.zip'))
    shutil._unpack_zipfile(os.path.join(target_dir, 'cmudict.zip'),
                           target_dir)


try:
    nltk.data.find('taggers/averaged_perceptron_tagger')
except LookupError:
    try:
        _create_unverified_https_context = ssl._create_unverified_context
    except AttributeError:
        pass
    else:
        ssl._create_default_https_context = _create_unverified_https_context

    nltk.download(
        'averaged_perceptron_tagger', halt_on_error=False, raise_on_error=True)

try:
    nltk.data.find('corpora/cmudict')
except LookupError:
    try:
        _create_unverified_https_context = ssl._create_unverified_context
    except AttributeError:
        pass
    else:
        ssl._create_default_https_context = _create_unverified_https_context

    nltk.download('cmudict', halt_on_error=False, raise_on_error=True)
