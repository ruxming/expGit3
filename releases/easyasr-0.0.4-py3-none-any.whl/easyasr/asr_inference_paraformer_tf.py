# Copyright (c) Alibaba, Inc. and its affiliates.

import os
import sys
import time
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np
import tensorflow as tf
import torch
import torchaudio
import torchaudio.compliance.kaldi as kaldi
from tensorflow.contrib.seq2seq.python.ops import \
    beam_search_ops  # very important
from tensorflow.python.ops import lookup_ops as lookup
from tensorflow.python.platform import gfile

from modelscope.utils.logger import get_logger

from .common import asr_utils, wav_utils

logger = get_logger()

header_colors = '\033[95m'
end_colors = '\033[0m'

global_asr_model_file = ''
global_feature_dims: int = 560
global_asr_language = 'zh-cn'
global_sampled_lengths = None
global_target_tokens = None


def count_lines(filename):
    with gfile.FastGFile(filename, mode='rb') as f:
        i = 0
        for i, _ in enumerate(f):
            pass
        return i + 1


def count_tfrecord(file_path):
    """
    Get the tfrecord count for data.records
    """
    count = 0
    for record in tf.python_io.tf_record_iterator(file_path):
        count += 1
    return count


def vocabulary_lookup_reverse(vocab: str):
    return lookup.index_to_string_table_from_file(
        vocab, vocab_size=count_lines(vocab), default_value='<unk>')


def print_bytes(str_as_bytes, stream=None, new_sentence=True):
    if stream is None:
        stream = sys.stdout
    write_buffer = stream.buffer if hasattr(stream, 'buffer') else stream
    write_buffer.write(str_as_bytes)
    if new_sentence:
        write_buffer.write(b'\n')
    else:
        write_buffer.write(b' ||| \n')
    stream.flush()


def parse_function(element):
    global global_feature_dims
    example = tf.parse_single_example(element,
                                      features={
                                          'shape': tf.VarLenFeature(tf.int64),
                                          'values':
                                          tf.VarLenFeature(tf.float32)
                                      })
    values = example['values'].values
    shape = tf.cast(example['shape'].values, tf.int32)
    tensor = tf.reshape(values, shape)
    tensor.set_shape([None, global_feature_dims])
    features = {}
    features['length'] = tf.shape(tensor)[0]
    features['tensor'] = tf.cast(tensor, tf.float32)
    return features


def build_CMVN_features(inputs, mvn_file):  # noqa
    """
    Do CMVN with am.mvn
    """
    with open(mvn_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()

    add_shift_list = []
    rescale_list = []
    for i in range(len(lines)):
        line_item = lines[i].split()
        if line_item[0] == '<AddShift>':
            line_item = lines[i + 1].split()
            if line_item[0] == '<LearnRateCoef>':
                add_shift_line = line_item[3:(len(line_item) - 1)]
                add_shift_list = list(add_shift_line)
                continue
        elif line_item[0] == '<Rescale>':
            line_item = lines[i + 1].split()
            if line_item[0] == '<LearnRateCoef>':
                rescale_line = line_item[3:(len(line_item) - 1)]
                rescale_list = list(rescale_line)
                continue

    for j in range(inputs.shape[1]):
        for k in range(inputs.shape[2]):
            add_shift_value = add_shift_list[k]
            rescale_value = rescale_list[k]
            inputs[0, j, k] = float(inputs[0, j, k]) + float(add_shift_value)
            inputs[0, j, k] = float(inputs[0, j, k]) * float(rescale_value)

    return inputs


def build_LFR_features(inputs, m=7, n=6):  # noqa
    """
    Actually, this implements stacking frames and skipping frames.
    if m = 1 and n = 1, just return the origin features.
    if m = 1 and n > 1, it works like skipping.
    if m > 1 and n = 1, it works like stacking but only support right frames.
    if m > 1 and n > 1, it works like LFR.

    Args:
        inputs_batch: inputs is T x D np.ndarray
        m: number of frames to stack
        n: number of frames to skip
    """
    # LFR_inputs_batch = []
    # for inputs in inputs_batch:
    LFR_inputs = []
    T = inputs.shape[0]
    T_lfr = int(np.ceil(T / n))
    for i in range(T_lfr):
        if m <= T - i * n:
            LFR_inputs.append(np.hstack(inputs[i * n:i * n + m]))
        else:  # process last LFR frame
            num_padding = m - (T - i * n)
            frame = np.hstack(inputs[i * n:])
            for _ in range(num_padding):
                frame = np.hstack((frame, inputs[-1]))
            LFR_inputs.append(frame)
    return np.vstack(LFR_inputs)


def compute_fbank(wav_file,
                  num_mel_bins=80,
                  frame_length=25,
                  frame_shift=10,
                  dither=0.0,
                  is_pcm=False,
                  fs: Union[int, Dict[Any, int]] = 16000):
    audio_sr: int = 16000
    model_sr: int = 16000
    if isinstance(fs, int):
        model_sr = fs
        audio_sr = fs
    else:
        model_sr = fs['model_fs']
        audio_sr = fs['audio_fs']

    if is_pcm is True:
        # byte(PCM16) to float32, and resample
        value = wav_file
        middle_data = np.frombuffer(value, dtype=np.int16)
        middle_data = np.asarray(middle_data)
        if middle_data.dtype.kind not in 'iu':
            raise TypeError("'middle_data' must be an array of integers")
        dtype = np.dtype('float32')
        if dtype.kind != 'f':
            raise TypeError("'dtype' must be a floating point type")

        i = np.iinfo(middle_data.dtype)
        abs_max = 2**(i.bits - 1)
        offset = i.min + abs_max
        waveform = np.frombuffer(
            (middle_data.astype(dtype) - offset) / abs_max, dtype=np.float32)
        waveform = wav_utils.ndarray_resample(waveform, audio_sr, model_sr)
        waveform = torch.from_numpy(waveform.reshape(1, -1))
    else:
        # load pcm from wav, and resample
        waveform, audio_sr = torchaudio.load(wav_file)
        waveform = waveform * (1 << 15)
        waveform = wav_utils.torch_resample(waveform, audio_sr, model_sr)

    mat = kaldi.fbank(waveform,
                      num_mel_bins=num_mel_bins,
                      frame_length=frame_length,
                      frame_shift=frame_shift,
                      dither=dither,
                      energy_floor=0.0,
                      window_type='hamming',
                      sample_frequency=model_sr)

    input_feats = mat

    return input_feats


def get_sentence(target_token: List[Any], lang: str = 'zh-cn'):
    word_lists = []
    word_item = ''

    for i in target_token:
        word = ''
        if isinstance(i, str):
            word = i
        else:
            word = i.decode('utf-8')

        if lang == 'zh-cn':
            if word != '</s>':
                word_lists.append(word)
        else:
            if '@@' in word:
                word = word.replace('@@', '')
                word_item += word
            elif word in ['<s>', '</s>']:
                continue
            else:
                word_item += word
                word_lists.append(word_item)
                word_lists.append(' ')
                word_item = ''

    sentence = ''.join(word_lists).strip()
    return sentence


def inference_with_wav(scp_list: Union[List[Any],
                                       bytes], predictions_file: str,
                       am_mvn_file: str, fs: Union[int, Dict[Any, int]],
                       feature_dims: int, tf_session, target_tokens, inputs,
                       input_lengths, sampled_lengths, lang):
    """
    Load waveform -> Fbank -> Do LFR6 -> Do CMVN -> Inference
    """

    finish_count: int = 0
    length_total = 0.0
    forward_time_total = 0.0
    asr_result_list = []

    if isinstance(scp_list, bytes):
        wav_count: int = 1
        time_beg = time.time()

        wav_key = 'pcm_data'
        features = compute_fbank(scp_list, is_pcm=True, fs=fs)
        features = build_LFR_features(features, 7, 6)
        features = features[None, :]
        features = build_CMVN_features(features, am_mvn_file)
        feature_length = features.shape[1]
        length_total += feature_length

        inputs_ = features
        input_lengths_ = [features.shape[1]]

        target_tokens_, logits_ = tf_session.run(
            [target_tokens, sampled_lengths],
            feed_dict={
                inputs: inputs_,
                input_lengths: input_lengths_
            })
        sentence = get_sentence(target_tokens_[0][0], lang)
        item = {'key': wav_key, 'value': sentence}
        asr_result_list.append(item)

        finish_count += 1
        asr_utils.print_progress(finish_count / wav_count)
        time_end = time.time()
        forward_time = time_end - time_beg
        forward_time_total += forward_time

    else:
        wav_count: int = len(scp_list)
        for wav_item in scp_list:
            time_beg = time.time()

            wav_key = wav_item['key']
            wav_file = wav_item['file']

            features = compute_fbank(wav_file, is_pcm=False, fs=fs)
            features = build_LFR_features(features, 7, 6)
            features = features[None, :]
            features = build_CMVN_features(features, am_mvn_file)
            feature_length = features.shape[1]
            length_total += feature_length

            try:
                inputs_ = features
                input_lengths_ = [features.shape[1]]

                target_tokens_, logits_ = tf_session.run(
                    [target_tokens, sampled_lengths],
                    feed_dict={
                        inputs: inputs_,
                        input_lengths: input_lengths_
                    })
                sentence = get_sentence(target_tokens_[0][0], lang)
                item = {'key': wav_key, 'value': sentence}
                asr_result_list.append(item)

                finish_count += 1
                asr_utils.print_progress(finish_count / wav_count)
                time_end = time.time()
                forward_time = time_end - time_beg
                forward_time_total += forward_time

            except tf.errors.OutOfRangeError:
                logger.info('All asr inference threads done.')
                break
            except Exception as e:
                logger.error(e)

    return forward_time_total, length_total, asr_result_list


def inference_with_tfrecord(tfrecord_file: str, idx_text_file: str,
                            predictions_file: str, fs: Union[int, Dict[Any,
                                                                       int]],
                            feature_dims: int, tf_session, target_tokens,
                            inputs, input_lengths, sampled_lengths, lang):
    features_count: int = count_tfrecord(tfrecord_file)

    dataset = tf.data.TFRecordDataset(tfrecord_file)
    new_dataset = dataset.map(parse_function)
    iterator = new_dataset.make_one_shot_iterator()
    next_element = iterator.get_next()

    # generate reference text index lists from idx_text
    with open(idx_text_file, 'r', encoding='utf-8') as f:
        idx_lists = f.readlines()

    if len(idx_lists) < features_count:
        raise ValueError('reference index text is mismatching')

    asr_result_list = []
    finish_count: int = 0
    length_total = 0.0
    forward_time_total = 0.0
    while True:
        try:
            time_beg = time.time()
            features = tf_session.run(next_element)
            inputs_ = np.reshape(features['tensor'], [1, -1, feature_dims])
            input_lengths_ = [features['length']]
            length_total += features['length']

            target_tokens_, logits_ = tf_session.run(
                [target_tokens, sampled_lengths],
                feed_dict={
                    inputs: inputs_,
                    input_lengths: input_lengths_
                })
            sentence = get_sentence(target_tokens_[0][0], lang)
            item = {'key': idx_lists[finish_count].strip(), 'value': sentence}
            asr_result_list.append(item)

            finish_count += 1
            asr_utils.print_progress(finish_count / features_count)
            time_end = time.time()
            forward_time = time_end - time_beg
            forward_time_total += forward_time

        except tf.errors.OutOfRangeError:
            logger.info('All asr inference threads done.')
            break
        except Exception as e:
            logger.error(e)

    return forward_time_total, length_total, asr_result_list


def set_parameters(language: str = None):
    if language is not None:
        global global_asr_language
        global_asr_language = language


def preload(ngpu: int,
            asr_model_file: Optional[str],
            vocab_file: Optional[str],
            sampled_ids: Optional[str] = 'seq2seq/sampled_ids',
            sampled_lengths: Optional[str] = 'seq2seq/sampled_lengths'):
    assert os.path.exists(
        asr_model_file), f'asr_model_file {asr_model_file} does not exist'
    assert os.path.exists(
        vocab_file), f'vocab_file {vocab_file} does not exist'

    global global_asr_model_file
    global global_sampled_lengths
    global global_target_tokens
    global global_feature_dims

    # force use CPU
    os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

    global_asr_model_file = asr_model_file
    sess = tf.compat.v1.get_default_session()
    if sess is not None:
        sess.close()
    tf.compat.v1.reset_default_graph()
    sess = tf.compat.v1.InteractiveSession()
    sess.as_default()

    # load graph
    with gfile.FastGFile(asr_model_file, 'rb') as f:
        graph_def = tf.compat.v1.GraphDef()
        graph_def.ParseFromString(f.read())
        sess.graph.as_default()
        tf.import_graph_def(graph_def, name='')

    sampled_ids = sess.graph.get_tensor_by_name('{}:0'.format(sampled_ids))
    target_vocab_rev = vocabulary_lookup_reverse(vocab_file)
    target_tokens = target_vocab_rev.lookup(tf.cast(sampled_ids, tf.int64))
    global_target_tokens = target_tokens
    sampled_lengths = sess.graph.get_tensor_by_name(
        '{}:0'.format(sampled_lengths))
    global_sampled_lengths = sampled_lengths

    sess.run(tf.compat.v1.tables_initializer())
    sess.run(tf.compat.v1.global_variables_initializer())

    # tf load an example wav file
    example_wav = os.path.join(os.path.dirname(__file__), 'example',
                               'asr_example.wav')

    inputs = sess.graph.get_tensor_by_name('tensor:0')
    input_lengths = sess.graph.get_tensor_by_name('length:0')

    features = compute_fbank(example_wav, is_pcm=False, fs=16000)
    features = build_LFR_features(features, 7, 6)
    features = features[None, :]

    sess.run([target_tokens, sampled_lengths],
             feed_dict={
                 inputs: features,
                 input_lengths: [features.shape[1]]
             })


def asr_inference(ngpu: int,
                  name_and_type: Sequence[Tuple[str, str]],
                  audio_lists: Union[str, List[Any], bytes],
                  idx_text_file: Optional[str],
                  asr_model_file: Optional[str],
                  vocab_file: Optional[str],
                  am_mvn_file: Optional[str],
                  predictions_file: Optional[str],
                  fs: Union[int, Dict[Any, int]] = 16000,
                  hop_length: int = 160,
                  feature_dims: int = 560,
                  sampled_ids: Optional[str] = 'seq2seq/sampled_ids',
                  sampled_lengths: Optional[str] = 'seq2seq/sampled_lengths',
                  lang: Optional[str] = None):
    # force use CPU if data type is bytes
    if isinstance(audio_lists, bytes):
        ngpu = 0
    if ngpu >= 1:
        os.environ['CUDA_VISIBLE_DEVICES'] = str(ngpu)
    else:
        os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

    if lang is not None:
        global global_asr_language
        global_asr_language = lang

    global global_asr_model_file
    global global_sampled_lengths
    global global_target_tokens
    global global_feature_dims
    global_feature_dims = feature_dims

    features_type: str = name_and_type[1]

    sess = tf.compat.v1.get_default_session()

    # 0. close old tf-session if loading new model
    if asr_model_file != global_asr_model_file:
        global_asr_model_file = asr_model_file
        if sess is not None:
            sess.close()
            sess = None

    # 1. create new tf-session and load graph if new inference
    if sess is None:
        global_sampled_lengths = None
        global_target_tokens = None

        tf.compat.v1.reset_default_graph()
        sess = tf.compat.v1.InteractiveSession()
        sess.as_default()

        # load graph
        with gfile.FastGFile(asr_model_file, 'rb') as f:
            graph_def = tf.compat.v1.GraphDef()
            graph_def.ParseFromString(f.read())
            sess.graph.as_default()
            tf.import_graph_def(graph_def, name='')

    if global_sampled_lengths is not None:
        sampled_lengths = global_sampled_lengths
    else:
        sampled_lengths = sess.graph.get_tensor_by_name(
            '{}:0'.format(sampled_lengths))
        global_sampled_lengths = sampled_lengths

    # 2. init new vocab tables if new inference
    target_tokens = None
    if global_target_tokens is not None:
        target_tokens = global_target_tokens
    else:
        sampled_ids = sess.graph.get_tensor_by_name('{}:0'.format(sampled_ids))
        target_vocab_rev = vocabulary_lookup_reverse(vocab_file)
        target_tokens = target_vocab_rev.lookup(tf.cast(sampled_ids, tf.int64))
        global_target_tokens = target_tokens

        sess.run(tf.compat.v1.tables_initializer())
        sess.run(tf.compat.v1.global_variables_initializer())

    inputs = sess.graph.get_tensor_by_name('tensor:0')
    input_lengths = sess.graph.get_tensor_by_name('length:0')

    time_total = 0.0
    length_total = 0.0
    asr_result_list = []

    # 3. start inference ...
    if features_type == 'tfrecord':
        time_total, length_total, asr_result_list = inference_with_tfrecord(
            tfrecord_file=audio_lists,
            idx_text_file=idx_text_file,
            predictions_file=predictions_file,
            fs=fs,
            feature_dims=feature_dims,
            tf_session=sess,
            target_tokens=target_tokens,
            inputs=inputs,
            input_lengths=input_lengths,
            sampled_lengths=sampled_lengths,
            lang=global_asr_language)
    elif features_type == 'sound':
        time_total, length_total, asr_result_list = inference_with_wav(
            scp_list=audio_lists,
            predictions_file=predictions_file,
            am_mvn_file=am_mvn_file,
            fs=fs,
            feature_dims=feature_dims,
            tf_session=sess,
            target_tokens=target_tokens,
            inputs=inputs,
            input_lengths=input_lengths,
            sampled_lengths=sampled_lengths,
            lang=global_asr_language)
    else:
        raise ValueError(f'feature type {features_type} is mismatching')

    sr: int = 16000
    if isinstance(fs, int):
        sr = fs
    else:
        sr = fs['model_fs']
    length_total_seconds = length_total * hop_length * 6 / sr
    length_total_bytes = length_total * hop_length * 6 * 2

    logger.info(
        header_colors +  # noqa: *
        'decoding, feature length total: {}bytes, forward_time total: {:.4f}s, rtf avg: {:.4f}'  # noqa: *
        .format(length_total_bytes, time_total, time_total /
                length_total_seconds) + end_colors)

    return asr_result_list
