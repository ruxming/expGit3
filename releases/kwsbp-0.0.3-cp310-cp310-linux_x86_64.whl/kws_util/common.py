import os
import json
from typing import Any, Dict, List, Union
import pkg_resources


def get_version():
    return pkg_resources.get_distribution('kwsbp').version


def parsing_kws_result(kws_type: str, pos_list: List[Any] = None, neg_list: List[Any] = None) -> Dict[str, Any]:
    rst_dict = {'kws_type': kws_type}

    # parsing the result of wav
    if kws_type == 'wav' or kws_type == 'pcm':
        pos_file_list = []
        for item in pos_list:
            rst_item = {}
            pos_file_list.append(item['filename'])

            if item['keyword'] is None or item['keyword'] == 'None':
                continue

            rst_item['keyword'] = item['keyword']
            rst_item['offset'] = round(item['offset'], 6)
            rst_item['length'] = round(item['wav_time'], 6)
            rst_item['confidence'] = round(item['confidence'], 6)

            old_list = []
            if rst_dict.__contains__('kws_list'):
                old_list = rst_dict['kws_list']
            old_list.append(rst_item)
            rst_dict['kws_list'] = old_list

        pos_file_list = list(set(pos_file_list))
        rst_dict['wav_count'] = len(pos_file_list)

    # parsing the result of pos_tests
    elif kws_type == 'pos_testsets':
        wav_time = 0.0
        detected_count = 0
        rejected_count = 0
        pos_file_list = []
        for item in pos_list:
            pos_file_list.append(item['filename'])
            wav_time += item['wav_time']

            if item['keyword'] == 'None':
                # add rejected wav
                rejected_list = []
                if rst_dict.__contains__('rejected'):
                    rejected_list = rst_dict['rejected']
                filename = os.path.basename(item['filename'])
                rejected_list.append(filename)
                rst_dict['rejected'] = rejected_list

                rejected_count += 1
                continue

            # add keyword
            keywords_list = []
            if rst_dict.__contains__('keywords'):
                keywords_list = rst_dict['keywords']
            if item['keyword'] not in keywords_list:
                keywords_list.append(item['keyword'])
            rst_dict['keywords'] = keywords_list
            detected_count += 1

        pos_file_list = list(set(pos_file_list))
        rst_dict['wav_count'] = len(pos_file_list)

        rst_dict['recall'] = round(detected_count / rst_dict['wav_count'],
                                       6)
        rst_dict['detected_count'] = detected_count
        rst_dict['rejected_count'] = rejected_count
        rst_dict['wav_time'] = round(wav_time, 6)

    # parsing the result of neg_tests
    elif kws_type == 'neg_testsets':
        wav_time = 0.0
        detected_count = 0
        rejected_count = 0
        neg_file_list = []
        for item in neg_list:
            neg_file_list.append(item['filename'])
            wav_time += item['wav_time']

            if item['keyword'] != 'None':
                # add keyword
                keywords_list = []
                if rst_dict.__contains__('keywords'):
                    keywords_list = rst_dict['keywords']
                if item['keyword'] not in keywords_list:
                    keywords_list.append(item['keyword'])
                rst_dict['keywords'] = keywords_list

                # add detected wav
                file_item = {}
                file_item['confidence'] = round(item['confidence'], 6)
                file_item['keyword'] = item['keyword']
                detected_list = []
                if rst_dict.__contains__('detected'):
                    detected_list = rst_dict['detected']
                detected_item = {}
                filename = os.path.basename(item['filename'])
                detected_item[filename] = file_item
                detected_list.append(detected_item)
                rst_dict['detected'] = detected_list

                detected_count += 1
                continue

            rejected_count += 1

        neg_file_list = list(set(neg_file_list))
        rst_dict['wav_count'] = len(neg_file_list)

        rst_dict['fa_rate'] = round(detected_count / rst_dict['wav_count'],
                                        6)
        rst_dict['fa_per_hour'] = round(
            detected_count / float(wav_time / 3600), 6)
        rst_dict['detected_count'] = detected_count
        rst_dict['rejected_count'] = rejected_count
        rst_dict['wav_time'] = round(wav_time, 6)

    # parsing the result of roc
    elif kws_type == 'roc':
        kws_list = pos_list + neg_list
        threshold_start = 0.000
        threshold_step = 0.001
        threshold_end = 1.000

        # find all keywords
        keywords_list = []
        for item in kws_list:
            if item['keyword'] != 'None' and item[
                    'keyword'] not in keywords_list:
                keywords_list.append(item['keyword'])
        rst_dict['keywords'] = keywords_list

        for keyword in keywords_list:
            threshold = threshold_start
            while threshold <= threshold_end:
                neg_wav_time = 0.0
                detected_count = 0
                fa_count = 0
                for item in pos_list:
                    if item['keyword'] == keyword:
                        confidence = float(item['confidence'])
                        if confidence >= threshold:
                            detected_count += 1

                for item in neg_list:
                    neg_wav_time += item['wav_time']
                    if item['keyword'] == keyword:
                        confidence = float(item['confidence'])
                        if confidence >= threshold:
                            fa_count += 1

                output_item = {
                    'threshold':
                    round(threshold, 3),
                    'recall':
                    round(float(detected_count / len(pos_list)), 6),
                    'fa_per_hour':
                    round(fa_count / float(neg_wav_time / 3600), 6)
                }

                keyword_item_list = []
                if rst_dict.__contains__(keyword):
                    keyword_item_list = rst_dict[keyword]
                keyword_item_list.append(output_item)
                rst_dict[keyword] = keyword_item_list
                threshold += threshold_step

    return rst_dict


def generate_customized_keywords(keywords: Dict[str, Any]) -> str:
    if keywords is not None:
        word_list_inputs = keywords
        word_list = []
        for i in range(len(word_list_inputs)):
            key = word_list_inputs[i]
            new_item = {}
            if key.__contains__('keyword'):
                name = key['keyword']
                new_name: str = ''
                for n in range(0, len(name), 1):
                    new_name += name[n]
                    new_name += ' '
                new_name = new_name.strip()
                new_item['name'] = new_name

                if key.__contains__('threshold'):
                    threshold1: float = key['threshold']
                    new_item['threshold1'] = threshold1

            word_list.append(new_item)
        out = {'word_list': word_list}
        return json.dumps(out)
    else:
        return ''

def recursion_dir_all_wav(wav_list: List[Any], wav_dir: str) -> List[Any]:
    dir_files = os.listdir(wav_dir)
    for file in dir_files:
        file_path = os.path.join(wav_dir, file)
        if os.path.isfile(file_path):
            if file_path.endswith('.wav') or file_path.endswith('.WAV'):
                wav_list.append(file_path)
        elif os.path.isdir(file_path):
            recursion_dir_all_wav(wav_list, file_path)

    return wav_list

def type_checking(audio_in: Union[List[str], str, bytes]) -> str:
    kws_type: str = 'unknown'
    if isinstance(audio_in, bytes):
        kws_type = 'pcm'
    elif isinstance(audio_in, str):
        kws_type = 'wav'
    else:
        if len(audio_in) == 1 and audio_in[0] is not None:
            if os.path.isfile(audio_in[0]):
                kws_type = 'wav'
            elif os.path.isdir(audio_in[0]):
                kws_type = 'pos_testsets'
        elif len(audio_in) == 2:
            if audio_in[0] is not None and audio_in[1] is None:
                if os.path.isdir(audio_in[0]):
                    kws_type = 'pos_testsets'
                elif os.path.isfile(audio_in[0]):
                    kws_type = 'wav'
            elif audio_in[0] is None and audio_in[1] is not None:
                if os.path.isdir(audio_in[1]):
                    kws_type = 'neg_testsets'
            elif audio_in[0] is not None and audio_in[1] is not None:
                if os.path.isdir(audio_in[0]) and os.path.isdir(audio_in[1]):
                    kws_type = 'roc'

    return kws_type



