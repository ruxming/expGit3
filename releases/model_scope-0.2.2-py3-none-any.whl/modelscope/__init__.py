# Copyright (c) Alibaba, Inc. and its affiliates.
from .version import __version__

__all__ = ['__version__']
