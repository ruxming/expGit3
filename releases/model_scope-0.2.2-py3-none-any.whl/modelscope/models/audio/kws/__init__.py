from .generic_key_word_spotting import *  # noqa F403
