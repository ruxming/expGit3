def hierarchical_set_score(frame1, frame2):
    # deal with empty frame
    if not (frame1 and frame2):
        return 0.
    pass
    return 0.
