from .clip import load_from_config
