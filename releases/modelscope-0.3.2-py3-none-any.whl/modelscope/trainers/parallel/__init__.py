# Copyright (c) Alibaba, Inc. and its affiliates.
from .builder import PARALLEL
