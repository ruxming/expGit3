"""
mmdet_patch is based on
https://github.com/deepinsight/insightface/tree/master/detection/scrfd/mmdet,
all duplicate functions from official mmdetection are removed.
"""
