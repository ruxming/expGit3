from .scrfd import SCRFD

__all__ = ['SCRFD']
