from .bbox_nms import multiclass_nms

__all__ = ['multiclass_nms']
