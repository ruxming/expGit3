from .clip_trainer import CLIPTrainer
