from .resnet import ResNetV1e

__all__ = ['ResNetV1e']
