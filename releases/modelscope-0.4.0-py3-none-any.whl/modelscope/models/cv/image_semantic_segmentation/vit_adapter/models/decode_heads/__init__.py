from .mask2former_head_from_mmseg import Mask2FormerHeadFromMMSeg

__all__ = ['Mask2FormerHeadFromMMSeg']
