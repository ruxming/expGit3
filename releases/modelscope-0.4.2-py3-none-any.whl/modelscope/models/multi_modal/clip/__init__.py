from .model import CLIPForMultiModalEmbedding
