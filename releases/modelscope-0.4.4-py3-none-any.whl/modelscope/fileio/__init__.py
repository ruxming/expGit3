from .file import File, LocalStorage
from .io import dump, dumps, load
