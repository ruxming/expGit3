from .fcn_mask_head import FCNMaskNHead

__all__ = ['FCNMaskNHead']
