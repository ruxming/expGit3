# The implementation is based on YOLOX, available at https://github.com/Megvii-BaseDetection/YOLOX

from .base_exp import BaseExp
from .build import get_exp_by_name
from .yolox_base import Exp
