from .encoder_decoder_mask2former import EncoderDecoderMask2Former

__all__ = ['EncoderDecoderMask2Former']
