# Copyright (c) Alibaba, Inc. and its affiliates.

from .kantts_sambert import *  # noqa F403
