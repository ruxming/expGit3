# The implementation is adopted from VitAdapter,
# made publicly available under the Apache License at https://github.com/czczup/ViT-Adapter.git
from .mask2former_head_from_mmseg import Mask2FormerHeadFromMMSeg

__all__ = ['Mask2FormerHeadFromMMSeg']
