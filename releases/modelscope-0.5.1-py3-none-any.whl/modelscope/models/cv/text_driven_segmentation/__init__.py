# Copyright (c) Alibaba, Inc. and its affiliates.
from .lseg_base import TextDrivenSegmentation
