# Copyright 2021-2022 The Alibaba Fundamental Vision Team Authors. All rights reserved.

from .clip_for_mm_video_embedding import VideoCLIPForMultiModalEmbedding
