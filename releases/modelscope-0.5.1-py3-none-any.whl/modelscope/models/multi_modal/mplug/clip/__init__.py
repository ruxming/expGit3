# Copyright (c) Alibaba, Inc. and its affiliates.

from .clip import load_from_config
