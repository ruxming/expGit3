# Implementation in this file is modified based on ViTAE-Transformer
# Originally Apache 2.0 License and publicly avaialbe at https://github.com/ViTAE-Transformer/ViTDet
from .fpn import FPNF

__all__ = ['FPNF']
