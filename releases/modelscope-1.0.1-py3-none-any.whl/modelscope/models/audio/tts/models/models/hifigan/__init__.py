# Copyright (c) Alibaba, Inc. and its affiliates.

from .hifigan import *  # noqa F403
