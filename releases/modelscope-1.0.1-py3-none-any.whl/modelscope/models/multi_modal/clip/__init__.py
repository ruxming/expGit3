# Copyright (c) Alibaba, Inc. and its affiliates.

from .model import CLIPForMultiModalEmbedding
