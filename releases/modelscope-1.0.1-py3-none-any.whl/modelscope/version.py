# Make sure to modify __release_datetime__ to release time when making official release.
__version__ = '1.0.1'
# default release datetime for branches under active development is set
# to be a time far-far-away-into-the-future
__release_datetime__ = '2022-11-01 21:28:00'
