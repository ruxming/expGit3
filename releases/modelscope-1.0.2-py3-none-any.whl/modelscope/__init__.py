# Copyright (c) Alibaba, Inc. and its affiliates.
from .version import __release_datetime__, __version__

__all__ = ['__version__', '__release_datetime__']
