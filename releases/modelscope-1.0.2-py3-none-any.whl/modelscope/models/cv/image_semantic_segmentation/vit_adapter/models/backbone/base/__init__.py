# The implementation is adopted from VitAdapter,
# made publicly available under the Apache License at https://github.com/czczup/ViT-Adapter.git
from .beit import BASEBEiT

__all__ = ['BASEBEiT']
