# Implementation in this file is modified based on ViTAE-Transformer
# Originally Apache 2.0 License and publicly avaialbe at https://github.com/ViTAE-Transformer/ViTDet
from .fcn_mask_head import FCNMaskNHead

__all__ = ['FCNMaskNHead']
