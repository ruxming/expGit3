# Copyright (c) Alibaba, Inc. and its affiliates.
from .maskformer_semantic_head import MaskFormerSemanticHead
