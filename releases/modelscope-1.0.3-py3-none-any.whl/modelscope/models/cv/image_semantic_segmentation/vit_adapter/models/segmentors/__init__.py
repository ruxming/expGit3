# The implementation is adopted from VitAdapter,
# made publicly available under the Apache License at https://github.com/czczup/ViT-Adapter.git
from .encoder_decoder_mask2former import EncoderDecoderMask2Former

__all__ = ['EncoderDecoderMask2Former']
