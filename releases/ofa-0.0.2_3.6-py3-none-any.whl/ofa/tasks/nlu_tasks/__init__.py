from .sst2 import SST2Task
from .qqp import QQPTask
from .qnli import QNLITask
from .mrpc import MRPCTask
from .rte import RTETask
from .mnli import MNLITask
from .cola import COLATask