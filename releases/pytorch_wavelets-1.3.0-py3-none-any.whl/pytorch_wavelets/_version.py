# IMPORTANT: before release, remove the 'devN' tag from the release name
__version__ = '1.3.0'
