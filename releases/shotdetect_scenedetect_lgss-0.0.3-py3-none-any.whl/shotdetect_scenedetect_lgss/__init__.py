# ----------------------------------------------------------------------------------
# The codes below partially refer to the SceneSeg LGSS. 
# Github: https://github.com/AnyiRao/SceneSeg
# ----------------------------------------------------------------------------------
import os
import os.path as osp


from .shotdetect.detectors.average_detector import AverageDetector
from .shotdetect.detectors.content_detector_hsv_luv import \
    ContentDetectorHSVLUV
from .shotdetect.keyf_img_saver import generate_images, generate_images_txt
from .shotdetect.shot_manager import ShotManager
from .shotdetect.stats_manager import StatsManager
from .shotdetect.video_manager import VideoManager
from .shotdetect.video_splitter import split_video_ffmpeg


def shot_detect(video_pth,
                avg_sample = False,
                begin_time = 0.0,
                c = 120.0,
                begin_frame = 0,
                end_frame = 120,
                save_keyf = False,
                keep_resolution = False,
                print_result = False,
                split_video = False,
                **kwargs):
    """
    Args:
        avg_sample (bool): Detect with average sampling or not.
        begin_time (float):  The start FrameTimecode of the cut list.
            Used to generate the first shot's start time.
        end_time (float):  The end FrameTimecode of the cut list.
            Used to generate the last shot's end time.
        begin_frame (FrameTimecode):  The start frame of the cut list.
            Used to generate the first shot's start frame.
        end_frame (FrameTimecode):  The end frame of the cut list.
            Used to generate the last shot's end frame.
        save_keyf (bool): Save key frame of each detected shot.
        keep_resolution (bool): Use downscale operation to improve processing speed.
        print_result (bool): Print detected result.
        split_video (bool): Generate shot video of each detected shot.
    Returns:
        shot_keyf_lst  (List): list of key frame images of every detected shot
            [[keyf_img1, keyf_img2, keyf_img3],...]
        anno (Dict): dict of meta info
        shot2keyf (List): [[shot_id, keyf_id1, keyf_id2, keyf_id3],...]
    """
    
    if '://' not in video_pth:
        video_path = osp.abspath(video_pth)
        video_prefix = video_path.split('.')[0].split('/')[-1]  # video name
    else:
        video_path = video_pth
        video_prefix = 'demo'
    data_root = osp.join(os.getcwd(), 'results')

    video_manager = VideoManager([video_path])
    stats_manager = StatsManager()
    # Construct our shotManager and pass it our StatsManager.
    shot_manager = ShotManager(stats_manager)

    # Add ContentDetector algorithm (each detector's constructor
    # takes detector options, e.g. threshold).
    if avg_sample:
        shot_manager.add_detector(AverageDetector(shot_length=50))
    else:
        shot_manager.add_detector(ContentDetectorHSVLUV(threshold=20))
    base_timecode = video_manager.get_base_timecode()

    shot_list = []

    try:
        # Set begin and end time
        if begin_time > 0:
            start_time = base_timecode + begin_time
            end_time = base_timecode + end_time
            video_manager.set_duration(
                start_time=start_time, end_time=end_time)
        elif begin_frame > 0:
            start_frame = base_timecode + begin_frame
            end_frame = base_timecode + end_frame
            video_manager.set_duration(
                start_time=start_frame, end_time=end_frame)
            pass
        # Set downscale factor to improve processing speed.
        if keep_resolution:
            video_manager.set_downscale_factor(1)
        else:
            video_manager.set_downscale_factor()
        # Start video_manager.
        video_manager.start()

        # Perform shot detection on video_manager.
        shot_manager.detect_shots(frame_source=video_manager)

        # Obtain list of detected shots.
        shot_list = shot_manager.get_shot_list(base_timecode)

        num_shot = len(shot_list) - 1
        fps = video_manager.get_framerate()
        anno = [{
            'video_id': 'demo',
            'shot_id': str(i).zfill(4),
            'num_shot': num_shot,
            'boundary_label': 1,
            'fps': fps
        } for i in range(num_shot + 1)]

        # Each shot is a tuple of (start, end) FrameTimecodes.
        if print_result:
            print('List of shots obtained:')
            for i, shot in enumerate(shot_list):
                print('Shot %4d: Start %s / Frame %d, End %s / Frame %d' % (
                    i,
                    shot[0].get_timecode(),
                    shot[0].get_frames(),
                    shot[1].get_timecode(),
                    shot[1].get_frames(),
                ))
        # Save keyf img for each shot
        keyf_dir = None
        if save_keyf:
            keyf_dir = osp.join(data_root, 'shot_keyf', video_prefix)
        shot_keyf_lst = generate_images(
            video_manager, shot_list, keyf_dir, num_images=3)

        # Save keyf txt of frame ind
        shot2keyf = generate_images_txt(shot_list)

        # Split video into shot video
        if split_video:
            output_dir = osp.join(data_root, 'shot_split_video', video_prefix)
            split_video_ffmpeg([video_path],
                               shot_list,
                               output_dir,
                               suppress_output=False)

    finally:
        video_manager.release()

    return shot_keyf_lst, anno, shot2keyf


