from typing import Dict
import sys
import torch
from torch import Tensor

def rm_model_after_bert(state_dict: Dict[str, Tensor]) -> Dict[str, Tensor]:
    return {k.replace("bert.model", "bert"): v for k, v in state_dict.items()}

def replace_generator(state_dict: Dict[str, Tensor]) -> Dict[str, Tensor]:
    return {k.replace("generator.0", "generator.dense"): v for k, v in state_dict.items()}

if __name__ == "__main__":
    # load ckpt from argv
    ckpt_path = sys.argv[1]
    state_dict = torch.load(ckpt_path, map_location='cpu')
    # convert
    state_dict['model'] = rm_model_after_bert(state_dict['model'])
    state_dict['model'] = replace_generator(state_dict['model'])
    # save converted state_dict
    torch.save(state_dict, "pytorch_model.bin")