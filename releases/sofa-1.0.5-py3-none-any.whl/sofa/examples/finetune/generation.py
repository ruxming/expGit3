# coding=utf-8
# Copyright 2021-2022 The Alibaba DAMO NLP Team Authors.
# All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
import os
import types
from functools import reduce
import numpy as np

import torch
from torch import nn

logger = logging.getLogger(__name__)

def run_generation_hf(pretrain_model_path,
                      output_dir,
                      task_type,
                      train_file_path=None,
                      dataset_name="text",
                      dev_file_path=None,
                      child_tuning_type=None,
                      reserve_p=0.2,
                      sequence_length=128,
                      target_length=100,
                      map_function=None,
                      filter_function=None,
                      save_strategy="steps",
                      save_total_limit=1,
                      seed=42,
                      config_args=None,
                      num_train_epochs=3,
                      **kwargs,
                      ):
    """ TODO
    Run a generation task with transformers code.
    :param pretrain_model_path: The local dir of pretrained model
    :param output_dir: The output directory where the model predictions and checkpoints will be written
    :param task_type: The task type, only support generation currently
    :param train_file_path: The local dir of train file
    :param dataset_name: The dataset name passed into datasets.load_dataset. Default will be "text"
    :param dev_file_path: The local dir of dev file, which is used in cross-validation in training.
    :param child_tuning_type: The child_tuning type. Can be "ChildTuning-F", "ChildTuning-D" or None
    :param reserve_p: the drop-out rate of child_tuning, default 0.2
    :param sequence_length: The max sequence length for padding
    :param target_length: The max target length for padding in generative task
    :param map_function: An optional map function, will be used with datasets.map()
    :param filter_function: An optional filter function, will be used with datasets.filter()
    :param save_strategy: TrainingArguments.
    :param save_total_limit: TrainingArguments.
    :param seed: Random seed, default 42.
    :param num_train_epochs: Total number of training epochs to perform, default 3.0.
    :param kwargs: Other optional hyper-parameters which is used in TrainingArguments.
    :return: None
    """

    # sofa custom code
    if config_args is None:
        config_args = {}
    from ... import environ
    environ("huggingface")
    # end
    from transformers import TrainingArguments
    from transformers import Trainer, set_seed
    import datasets
    from datasets import load_dataset, interleave_datasets
    from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
    from transformers import TrainerCallback,  TrainerState, TrainerControl
    from transformers.tokenization_utils import PreTrainedTokenizer
    # sofa dureader_eval
    from ...utils.dureader_eval import normalize, compute_bleu_rouge
    # sofa child_tuning
    from ...utils import apply_child_tuning_to_trainer

    cache_dir = ".cache"
    if "cache_dir" in kwargs:
        cache_dir = kwargs["cache_dir"]

    set_seed(seed)
    # assert type(label) in (str, types.FunctionType)
    logger.info(f"Cuda available:{torch.cuda.is_available()}")

    # prepare data
    train_datasets = None
    dev_datasets = None

    def get_files(files_or_path):
        if type(files_or_path) is str:
            if os.path.isfile(files_or_path):
                return files_or_path
            if os.path.isdir(files_or_path):
                return [os.path.join(files_or_path, f) for f in os.listdir(files_or_path)]
        if type(files_or_path) is list:
            return files_or_path

    if train_file_path is not None:
        train_files = get_files(train_file_path)
        data_files = {"train": train_files}
        train_datasets = load_dataset(dataset_name, split="train", data_files=data_files)
    if train_datasets is None:
        logger.error(f"dataset_name and train_file_path cannot both be None")

    if dev_file_path is not None:
        dev_files = get_files(dev_file_path)
        data_files = {"dev": dev_files}
        dev_datasets = load_dataset(dataset_name, split="dev", data_files=data_files)

    if filter_function is not None:
        train_datasets = train_datasets.filter(filter_function)
        if dev_datasets:
            dev_datasets = dev_datasets.filter(filter_function)
    if map_function is not None:
        train_datasets = train_datasets.map(map_function)
        if dev_datasets:
            dev_datasets = dev_datasets.map(map_function)

    if task_type != "generation":
        raise RuntimeError(f"Unsupported task type:{task_type}")

    def split_text(example):
        text_a, text_b = example[dataset_name].split('\t')
        return {"text_a": text_a, "text_b": text_b}
        
    train_datasets = train_datasets.map(split_text, remove_columns=["text"])
    if dev_datasets:
        dev_datasets = dev_datasets.map(split_text, remove_columns=["text"])
    tokenizer = AutoTokenizer.from_pretrained(pretrain_model_path)
    model = AutoModelForSeq2SeqLM.from_pretrained(pretrain_model_path)

    kwargs_for_training = {}
    for p in TrainingArguments.__dataclass_fields__.keys():
        if p in kwargs:
            kwargs_for_training[p] = kwargs[p]
    kwargs_for_training["remove_unused_columns"] = False
    training_args = TrainingArguments(output_dir=output_dir,
                                      save_strategy=save_strategy,
                                      save_total_limit=save_total_limit,
                                      num_train_epochs=num_train_epochs,
                                      **kwargs_for_training)

    def tokenize_function(example):
        input_tokens = ["[CLS]"] + tokenizer.tokenize(example["text_a"]) + ["[SEP]"]
        if len(input_tokens) > sequence_length:
            input_tokens = input_tokens[:sequence_length-1] + ["[SEP]"]
        input_ids = tokenizer.convert_tokens_to_ids(input_tokens)
        input_mask = [1] * len(input_ids)
        segment_ids = [0] * len(input_ids)
        while len(input_ids) < sequence_length:
            input_ids.append(0)
            input_mask.append(0)
            segment_ids.append(0)
        target_tokens = ["[CLS]"] + tokenizer.tokenize(example["text_b"]) + ["[SEP]"]
        if len(target_tokens) > target_length:
            target_tokens = target_tokens[:target_length-1] + ["[SEP]"]
        target_ids = tokenizer.convert_tokens_to_ids(target_tokens)
        while len(target_ids) < target_length:
            target_ids.append(0)

        return {"input_ids": input_ids, "input_mask": input_mask,
                "segment_ids": segment_ids, "target_ids": target_ids}

    full_train_dataset = train_datasets.map(tokenize_function, remove_columns=["text_a", "text_b"])
    if dev_datasets:
        full_eval_dataset = dev_datasets.map(tokenize_function, remove_columns=["text_a", "text_b"])
    else:
        full_eval_dataset = None

    # Currently only supports palm model, better compatibility will be provided in the future
    class GeneratorCallback(TrainerCallback):
        def __init__(self, tokenizer: PreTrainedTokenizer, model: nn.Module, dataset: "datasets.Dataset", eval_batch_size: int = 16, num_workers: int = 1):
            from ...models.palm import TextGenerator
            self.beam_generator = TextGenerator(model, tokenizer)
            self.tokenizer = tokenizer
            self.model = model
            self.eval_iters = len(dataset) // eval_batch_size
            sampler = torch.utils.data.SequentialSampler(dataset)
            self.data_loader = torch.utils.data.DataLoader(dataset,
                                                           batch_size=eval_batch_size,
                                                           sampler=sampler,
                                                           num_workers=num_workers,
                                                           pin_memory=True,
                                                           collate_fn=model.palm_batchify)

        def on_epoch_end(self, args: TrainingArguments, state: TrainerState, control: TrainerControl, **kwargs):
            """Evaluation."""
            device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
            beam_generator, tokenizer, model, eval_iters, data_iterator = \
                self.beam_generator, self.tokenizer, self.model, self.eval_iters, iter(self.data_loader)

            # Turn on evaluation mode which disables dropout.
            model.eval()

            pred_dict = {}
            ref_dict = {}
            vocab_size = 21127
            counter_all = 0

            with torch.no_grad():
                iteration = 0
                while iteration < eval_iters:
                    iteration += 1
                    # Forward evaluation.
                    # tokens, types, padding_mask, target_tokens, target_labels, dec_loss_mask, attention_mask, position_ids = self.get_batch(data_iterator, args, timers)
                    data = next(data_iterator)
                    tokens, types, padding_mask, target_labels = data["input_tokens"].to(device), data["token_type_ids"].to(device), data["attention_mask"].to(device), data["labels"]
                    batch_size = tokens.size(0)
                    # sequence_output = self.model.bert(input_ids, token_type_ids, attention_mask,output_all_encoded_layers=False, checkpoint_activations=args.checkpoint_activations)
                    encoder_inputs = [tokens, types, padding_mask]

                    result_dict = beam_generator.translate_batch(encoder_inputs)
                    pred_list = result_dict["predictions"]
                    target_list = target_labels.cpu().numpy().tolist()
                    for i in range(batch_size):
                        pred_ids = pred_list[i][0].cpu().numpy().tolist()
                        for j in range(len(pred_ids)):
                            if pred_ids[j] > vocab_size-1:
                                pred_ids[j] = 100
                        gold = tokenizer.convert_ids_to_tokens(target_list[i])
                        pred = tokenizer.convert_ids_to_tokens(pred_ids)
                        gold_string = "".join(gold).replace("##", "").split("[SEP]")[0].replace("[CLS]", "").replace("[SEP]", "").replace("[UNK]", "")
                        pred_string = "".join(pred).replace("##", "").split("[SEP]")[0].replace("[CLS]", "").replace("[SEP]", "").replace("[UNK]", "")
                        if len(gold_string) < 3:
                            continue
                        pred_dict[str(counter_all)] = normalize([pred_string])
                        ref_dict[str(counter_all)] = normalize([gold_string])
                        counter_all += 1
            bleu_rouge = compute_bleu_rouge(pred_dict, ref_dict)
            print (ref_dict["0"])
            print (pred_dict["0"])
            print("test result %d: " % counter_all, bleu_rouge)

    trainer = Trainer(model=model,
                      args=training_args,
                      data_collator=model.palm_batchify,
                      train_dataset=full_train_dataset,
                      callbacks=[GeneratorCallback(tokenizer, model, full_eval_dataset)])

    # apply child_tuning or not.
    if child_tuning_type is not None:
        logger.info("Applying child-tuning.")
        apply_child_tuning_to_trainer(trainer, mode=child_tuning_type, reserve_p=reserve_p)
    trainer.train()
