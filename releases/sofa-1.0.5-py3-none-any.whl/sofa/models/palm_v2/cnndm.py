# Copyright 2020 The HuggingFace Datasets Authors and the current dataset script contributor.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# TODO: Address all TODOs and remove all explanatory comments
"""TODO: Add a description here."""


import os
from typing import List

import datasets
import torch

# TODO: Add BibTeX citation
# Find for instance the citation on arxiv or on the dataset repo/website
_CITATION = """\
@InProceedings{huggingface:dataset,
title = {A great new dataset},
author={huggingface, Inc.
},
year={2020}
}
"""

# TODO: Add description of the dataset here
# You can copy an official description
_DESCRIPTION = """\
This new dataset is designed to solve this great NLP task and is crafted with a lot of care.
"""

_HOMEPAGE = ""
_LICENSE = ""
_URLS = {}


class CnndmConfig(datasets.BuilderConfig):

    def __init__(self, data_dir, src_max_len, tgt_max_len, **kwargs):
        super().__init__(**kwargs)
        self.data_dir = data_dir
        self.src_max_len = src_max_len
        self.tgt_max_len = tgt_max_len


class Cnndm(datasets.GeneratorBasedBuilder):
    """TODO: Short description of my dataset."""

    VERSION = datasets.Version("0.0.1")

    BUILDER_CONFIGS = [
        CnndmConfig(
            name="cnndm",
            version=VERSION,
            description="Load the tokenized cnndm dataset",
            data_dir="cnndm",
            src_max_len=512,
            tgt_max_len=140,
        ),
    ]

    def _info(self):
        features = datasets.Features(
            {
                "src": datasets.Sequence(datasets.Value("int32")),
                "tgt": datasets.Sequence(datasets.Value("int32")),
                "mask_src": datasets.Sequence(datasets.Value("int32")),
                "mask_tgt": datasets.Sequence(datasets.Value("int32")),
                "src_txt": datasets.Sequence(datasets.Value("string")),
                "tgt_txt": datasets.Value("string"),
            }
        )
        return datasets.DatasetInfo(
            description=_DESCRIPTION,
            features=features,
            homepage=_HOMEPAGE,
            license=_LICENSE,
            citation=_CITATION,
        )

    def _split_generators(self, dl_manager):
        return [
            datasets.SplitGenerator(
                name=datasets.Split.TRAIN,
                gen_kwargs={
                    "split": "train",
                },
            ),
            datasets.SplitGenerator(
                name=datasets.Split.TEST,
                gen_kwargs={
                    "split": "test"
                },
            ),
            datasets.SplitGenerator(
                name=datasets.Split.VALIDATION,
                gen_kwargs={
                    "split": "dev",
                },
            ),
        ]

    def _trunc_or_pad(self, ids: List[int], length: int) -> List[int]:
        if len(ids) <= length:
            ids += [0] * (length - len(ids))
        else:
            last = ids[-1]
            ids = ids[:length]
            ids[-1] = last
        return ids

    def _generate_examples(self, split: str):
        FILE_NAME_TEMPLATE= "cnndm.{type}.{index}.bert.pt"

        file_path = os.path.join(self.config.data_dir, FILE_NAME_TEMPLATE.replace("{type}", split))
        i = 0
        key = 0
        while os.path.exists(file_path.replace('{index}', str(i))):
            lst = torch.load(file_path.replace('{index}', str(i)))
            for tmp_dict in lst:
                src = self._trunc_or_pad(tmp_dict["src"], self.config.src_max_len)
                tgt = self._trunc_or_pad(tmp_dict["tgt"], self.config.tgt_max_len)
                mask_src = [int(token != 0) for token in src]
                mask_tgt = [int(token != 0) for token in tgt]
                src_txt = tmp_dict["src_txt"] if split == "test" else []
                tgt_txt = tmp_dict["tgt_txt"] if split == "test" else ""
                yield key, {
                    "src": src,
                    "tgt": tgt,
                    "mask_src": mask_src,
                    "mask_tgt": mask_tgt,
                    "src_txt": src_txt,
                    "tgt_txt": tgt_txt,
                }
                key += 1
            i += 1